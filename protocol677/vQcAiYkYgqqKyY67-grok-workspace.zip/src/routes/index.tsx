import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="relative h-screen w-screen overflow-hidden bg-[#050508]">
      <iframe
        title="Protocol 67: Phase Shift"
        src="/Protocol67_PhaseShift.html"
        className="absolute inset-0 h-full w-full border-0"
        allow="fullscreen; autoplay"
      />
      <a
        href="/Protocol67_PhaseShift.html"
        download="Protocol67_PhaseShift.html"
        className="absolute right-3 top-3 z-10 rounded border border-[#7b2cbf] bg-[#1a0a2ecc] px-3 py-1.5 text-xs tracking-widest text-[#c77dff] hover:bg-[#7b2cbf] hover:text-white"
      >
        BAIXAR HTML
      </a>
    </main>
  );
}
